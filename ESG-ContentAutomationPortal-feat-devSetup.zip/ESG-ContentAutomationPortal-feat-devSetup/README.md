# PythonAutomationEngine
An automation engine that reads, processes and runs scripts stored and maintained in the scripts folder and saves data into database
