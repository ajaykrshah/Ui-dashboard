import { mockApiActivityItems, mockApiDashboardStats } from '@/features/dashboard/mocks/data';
// You would also import products, executions, vendors mocks here as needed

export const dashboardStats = mockApiDashboardStats;
export const activity = mockApiActivityItems;
// export const products = ...;
// export const executions = ...;
// export const vendors = ...;
